using System.Collections.Generic;
using UnityEngine;

namespace Fu.Framework
{
    /// <summary>
    /// Generic Add supporting float + float = float, v2 + v2 = v2, and scalar promotion float + v2 (or v2 + float) = v2.
    /// </summary>
    public sealed class AddNode : FuNode
    {
        public override string Title => "Add";
        public override float Width => 200f;
        public override Color? NodeColor => null;

        public override bool CanConnect(FuNodalPort fromPort, FuNodalPort toPort)
        {
            string fromType = fromPort.DataType;
            string otherPortType = toPort.Name == "A" ? GetPortType("B") : GetPortType("A");

            // Allow connections if types are the same
            if (fromType == otherPortType)
                return true;

            // Allow scalar promotion for float and vector types
            if ((fromType == "core/float" && (otherPortType == "core/v2" || otherPortType == "core/v3")) ||
                (otherPortType == "core/float" && (fromType == "core/v2" || fromType == "core/v3")))
                return true;

            return false;
        }

        public override void Compute()
        {
            string aType = GetPortType("A");
            string bType = GetPortType("B");

            // Handle float + float
            if (aType == "core/float" && bType == "core/float")
            {
                float a = GetPortValue<float>("A", 0f);
                float b = GetPortValue<float>("B", 0f);
                SetPortValue("Out", "core/float", a + b);
                return;
            }

            // Handle v2 + v2
            if (aType == "core/v2" && bType == "core/v2")
            {
                Vector2 a = GetPortValue<Vector2>("A", Vector2.zero);
                Vector2 b = GetPortValue<Vector2>("B", Vector2.zero);
                SetPortValue("Out", "core/v2", a + b);
                return;
            }

            // Handle scalar promotion float + v2 or v2 + float
            if ((aType == "core/float" && bType == "core/v2") || (aType == "core/v2" && bType == "core/float"))
            {
                float scalar = aType == "core/float" ? GetPortValue<float>("A", 0f) : GetPortValue<float>("B", 0f);
                Vector2 vector = aType == "core/v2" ? GetPortValue<Vector2>("A", Vector2.zero) : GetPortValue<Vector2>("B", Vector2.zero);
                SetPortValue("Out", "core/v2", vector + new Vector2(scalar, scalar));
                return;
            }

            // Handle v3 + v3
            if (aType == "core/v3" && bType == "core/v3")
            {
                Vector3 a = GetPortValue<Vector3>("A", Vector3.zero);
                Vector3 b = GetPortValue<Vector3>("B", Vector3.zero);
                SetPortValue("Out", "core/v3", a + b);
                return;
            }

            // Handle scalar promotion float + v3 or v3 + float
            if ((aType == "core/float" && bType == "core/v3") || (aType == "core/v3" && bType == "core/float"))
            {
                float scalar = aType == "core/float" ? GetPortValue<float>("A", 0f) : GetPortValue<float>("B", 0f);
                Vector3 vector = aType == "core/v3" ? GetPortValue<Vector3>("A", Vector3.zero) : GetPortValue<Vector3>("B", Vector3.zero);
                SetPortValue("Out", "core/v3", vector + new Vector3(scalar, scalar, scalar));
                return;
            }

            // If types are incompatible, set output to zero of appropriate type
            if (aType == "core/v2" || bType == "core/v2")
            {
                SetPortValue("Out", "core/v2", Vector2.zero);
            }
            else if (aType == "core/v3" || bType == "core/v3")
            {
                SetPortValue("Out", "core/v3", Vector3.zero);
            }
            else
            {
                SetPortValue("Out", "core/float", 0f);
            }
        }

        public override void CreateDefaultPorts()
        {
            FuNodalPort portA = new FuNodalPort
            {
                Name = "A",
                Direction = FuNodalPortDirection.In,
                DataType = "core/float",
                AllowedTypes = new HashSet<string> { "core/float", "core/v2", "core/v3" },
                Data = 0f,
                Multiplicity = FuNodalMultiplicity.Single
            };
            AddPort(portA);

            FuNodalPort portB = new FuNodalPort
            {
                Name = "B",
                Direction = FuNodalPortDirection.In,
                DataType = "core/float",
                AllowedTypes = new HashSet<string> { "core/float", "core/v2", "core/v3" },
                Data = 0f,
                Multiplicity = FuNodalMultiplicity.Single
            };
            AddPort(portB);

            FuNodalPort portOut = new FuNodalPort
            {
                Name = "Out",
                Direction = FuNodalPortDirection.Out,
                DataType = "core/float",
                AllowedTypes = new HashSet<string> { "core/float", "core/v2", "core/v3" },
                Data = 0f,
                Multiplicity = FuNodalMultiplicity.Many
            };
            AddPort(portOut);
        }

        public override void OnDraw(FuLayout layout)
        {
            string outType = GetPortType("Out");
            switch (outType)
            {
                case "core/float":
                    layout.Text("Outputs a float");
                    float fVal = GetPortValue<float>("Out", 0f);
                    layout.DisableNextElement();
                    layout.Drag("##" + Id, ref fVal);
                    break;
                case "core/v2":
                    layout.Text("Outputs a Vector2");
                    Vector2 v2Val = GetPortValue<Vector2>("Out", Vector2.zero);
                    layout.DisableNextElement();
                    layout.Drag("##" + Id, ref v2Val);
                    break;
                case "core/v3":
                    layout.Text("Outputs a Vector3");
                    Vector3 v3Val = GetPortValue<Vector3>("Out", Vector3.zero);
                    layout.DisableNextElement();
                    layout.Drag("##" + Id, ref v3Val);
                    break;
                default:
                    layout.Text("unknown type : " + outType);
                    break;
            }
        }

        public override void SetDefaultValues(FuNodalPort port)
        {
                port.DataType = "core/float";
                port.Data = 0f;
        }
    }
}