using UnityEngine;

namespace Fu.Framework
{
    /// <summary>
    /// Float variable node
    /// </summary>
    public sealed class FloatNode : FuNode
    {
        public override string Title => "Float";
        public override float Width => 200f;
        public override Color? NodeColor => color;
        private Color color = new Color(0.8f, 0.8f, 0.8f);

        /// <summary>
        /// Constructor with optional color parameter to set the node's color.
        /// </summary>
        /// <param name="color"> The color to set for the node. Default is a light gray color.</param>
        public FloatNode(Color color)
        {
            this.color = color;
        }

        public override bool CanConnect(FuNodalPort fromPort, FuNodalPort toPort) => true;

        public override void Compute() { }

        public override void CreateDefaultPorts()
        {
            FuNodalPort portOut = new FuNodalPort
            {
                Name = "Out",
                Direction = FuNodalPortDirection.Out,
                DataType = "core/float",
                Data = 0f,
                Multiplicity = FuNodalMultiplicity.Many
            };
            AddPort(portOut);
        }

        public override void OnDraw(FuLayout layout)
        {
            float fVal = GetPortValue<float>("Out", 0f);
            if(layout.Drag("##" + Id, ref fVal))
                SetPortValue("Out", "core/float", fVal);
        }

        public override void SetDefaultValues(FuNodalPort port)
        {
            port.DataType = "core/float";
            port.Data = 0f;
        }
    }
}