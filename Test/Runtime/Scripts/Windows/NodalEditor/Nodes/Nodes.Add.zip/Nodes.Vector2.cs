using UnityEngine;

namespace Fu.Framework
{
    /// <summary>
    /// Float variable node
    /// </summary>
    public sealed class Vector2Node : FuNode
    {
        public override string Title => "Vector2";
        public override float Width => 200f;
        public override Color? NodeColor => color;
        private Color color = new Color(0.8f, 0.8f, 0.8f);

        /// <summary>
        /// Constructor with optional color parameter to set the node's color.
        /// </summary>
        /// <param name="color"> The color to set for the node. Default is a light gray color.</param>
        public Vector2Node(Color color)
        {
            this.color = color;
        }

        public override bool CanConnect(FuNodalPort fromPort, FuNodalPort toPort) => true;

        public override void Compute() { }

        public override void CreateDefaultPorts()
        {
            FuNodalPort portOut = new FuNodalPort
            {
                Name = "Out",
                Direction = FuNodalPortDirection.Out,
                DataType = "core/v2",
                Data = Vector2.zero,
                Multiplicity = FuNodalMultiplicity.Many
            };
            AddPort(portOut);
        }

        public override void OnDraw(FuLayout layout)
        {
            Vector2 fVal = GetPortValue<Vector2>("Out", Vector2.zero);
            if(layout.Drag("##" + Id, ref fVal))
                SetPortValue("Out", "core/v2", fVal);
        }

        public override void SetDefaultValues(FuNodalPort port)
        {
            port.DataType = "core/v2";
            port.Data = Vector2.zero;
        }
    }
}