using UnityEngine;

namespace Fu.Framework
{
    /// <summary>
    /// Float variable node
    /// </summary>
    public sealed class Vector3Node : FuNode
    {
        public override string Title => "Vector3";
        public override float Width => 200f;
        public override Color? NodeColor => color;

        private Color color = new Color(0.8f, 0.8f, 0.8f);

        /// <summary>
        /// Constructor with optional color parameter to set the node's color.
        /// </summary>
        /// <param name="color"> The color to set for the node. Default is a light gray color.</param>
        public Vector3Node(Color color)
        {
            this.color = color;
        }

        public override bool CanConnect(FuNodalPort fromPort, FuNodalPort toPort) => true;

        public override void Compute() { }

        public override void CreateDefaultPorts()
        {
            FuNodalPort portOut = new FuNodalPort
            {
                Name = "Out",
                Direction = FuNodalPortDirection.Out,
                DataType = "core/v3",
                Data = Vector3.zero,
                Multiplicity = FuNodalMultiplicity.Many
            };
            AddPort(portOut);
        }

        public override void OnDraw(FuLayout layout)
        {
            Vector3 fVal = GetPortValue<Vector3>("Out", Vector3.zero);
            if(layout.Drag("##" + Id, ref fVal))
                SetPortValue("Out", "core/v3", fVal);
        }

        public override void SetDefaultValues(FuNodalPort port)
        {
            port.DataType = "core/v3";
            port.Data = Vector3.zero;
        }
    }
}